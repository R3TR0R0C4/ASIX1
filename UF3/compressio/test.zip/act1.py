llegir=open("act1.txt")

for linia in llegir:
    print(linia.strip())