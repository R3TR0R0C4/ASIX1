llegir=open("act2.txt")


for linia in llegir.read().split(";"):
    print(linia)